<?php
// Define constants for roles
define('ROLE_ADMIN', 'admin');
define('ROLE_TEACHER', 'teacher');
define('ROLE_USER', 'user');

// Other constants
define('SITE_NAME', 'Contact Management System');
?>
